import { createAction } from "@reduxjs/toolkit";

export const resetState = createAction("state/reset");
